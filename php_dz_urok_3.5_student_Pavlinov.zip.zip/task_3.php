<?php

$a = rand(1, 9);
$b = rand(10, 30);
$c = $a * $b;
$c = $c + rand(0, 100);
var_dump($a, $b);

switch ($a * $b){
    case $c >= 0 && $c < 100:
        echo "вариант 1 ";
        break;
    case $c >= 100 && $c < 200:
        echo "вариант 2 ";
        break;
    case $c >= 200 && $c < 300:
        echo "вариант 3 ";
        break;
    default:
        echo "к сожалению, ни один вариант не подошёл ";
}

?>