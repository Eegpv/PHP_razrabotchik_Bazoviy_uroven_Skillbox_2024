<?php

$a = 8;
$b = rand(10, 30);

var_dump($a, $b);

if ($a * $b <100){
    echo "меньше 100";
} elseif ($a * $b <200){
    echo "меньше 200";
} else {
    echo "всё остальное";

}

?>