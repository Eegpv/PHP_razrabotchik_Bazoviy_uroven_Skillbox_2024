<?php

$a = rand(0, 1);
var_dump($a);
$b = $a ? null : rand(1, 3);
var_dump($b);

switch ($b) {
    case null:
        echo 'b равно null ';
        break;
    case 1:
        echo 'b равно 1 ';
        break;
    default:
    echo 'by default ';
    break;

}
var_dump(isset($b));

$c = $b ?? $c = rand(20,30);
echo $c;

?>