<?php

    $a = 5;
    $b = 5.55;
    $c = 6;

    var_dump($c <= $a + $b);

?>