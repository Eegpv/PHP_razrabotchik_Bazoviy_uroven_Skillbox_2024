<?php



$fraza = "Something beautiful";
$smeshenie = 4;

for ($i = 0; $i < strlen($fraza); $i++){
    $symbol = ord($fraza[$i]) + $smeshenie;

    if ($symbol !== ord(' ')) {  // Если текущий символ не пробел, шифровать

        $symbol += $smeshenie; 

    if ($symbol > 255) {  

        $symbol -= 255;  

        }  

        } 

    $codir = $codir . chr($symbol);

}
    echo $codir . PHP_EOL; 



    $codir = "";
    $smeshenie = 4;

    for ($i = 0; $i < strlen($codir); $i++){
        $symbol = ord ($codir[$i]) - $smeshenie;

        if ($symbol !== ord(' ')) { 

            $symbol -= $smeshenie; 

        if ($symbol < $smeshenie) {  

            $symbol = 255 - $smeshenie;  

            }  

            } 

        $fraza = $fraza . chr($symbol);
    }

        echo $fraza; 


?>
