<?php

$startSum = 100000;
$futureSum = $startSum*2;
$perYear = 8;
$every3 = 3;
$countYear = 0;

$deposit = $startSum;

for (; $deposit <= $futureSum; ++$countYear){
    
    if ($countYear % $every3 === 0){
        $perYear += 2;
    }

    $deposit += $deposit * ($perYear / 100);
 
    echo "\n лет прошло: ".$countYear. " " .
        "нынешний процент в год: ".$perYear . " " .
        " На депозите у нас:".(int)$deposit;
}

?>