<?php

$fraza = 'Я люблю море. Я лечу на море. Я умею плавать в море. Какое чистое море! Хочу на море. Завтра поедем на море';
$slovo = 'море';
$result = str_replace('море', 'МОРЕ', $slovo,);
$slovo = mb_strtoupper($slovo);
echo $slovo;

?>