<?php

$array1 = [

    'a' => 'one',
    'b' => 'two',
    'c' => 'three',
    'd' => 'two',
    'e' => 'five',

];

$countarray = sizeof($array1);
// var_dump($countarray);

$reversearray = array_flip($array1);
// var_dump($reversearray);

$countreverse = sizeof($reversearray);
// var_dump($countreverse);

// var_dump($countarray != $reversearray); //все выводы закоментил что бы не мешали в новом ДЗ

$newvar1 = array_values($reversearray);
$newvar2 = ['new',];
$newarray = array_merge($newvar1, $newvar2);
// var_dump($newarray);

// я немного запутался уже на этом месте, надеюсь сделал верно. или нужно было сначало использовать -
// - array_values на $newarray, а только затем делать array_combine с $array1?
// по идее "array_combine — Создаёт новый массив, используя один массив в качестве ключей, а другой для его значений"
$combinedarr = array_combine($newarray, $array1);
var_dump($combinedarr);


?>