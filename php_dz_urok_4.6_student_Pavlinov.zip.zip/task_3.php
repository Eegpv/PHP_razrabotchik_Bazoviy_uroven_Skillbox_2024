<?php

$array1 = [

    'a' => 'value one',
    'b' => 'value two',
    'c' => 'value three',

];

$array2 = array_keys($array1);
// var_dump($array2);

$string1 = implode(' ', $array2);
echo $string1;

?>