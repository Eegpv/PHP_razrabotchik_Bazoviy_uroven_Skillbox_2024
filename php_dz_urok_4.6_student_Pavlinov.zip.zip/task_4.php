<?php

$array1 = [

    'a' => 'one',
    'b' => 'two',
    'c' => 'three',
    'd' => 'two',
    'e' => 'five',

];

$countarray = sizeof($array1);
var_dump($countarray);

$reversearray = array_flip($array1);
// var_dump($reversearray);

$countreverse = sizeof($reversearray);
var_dump($countreverse);

var_dump($countarray != $reversearray);

?>